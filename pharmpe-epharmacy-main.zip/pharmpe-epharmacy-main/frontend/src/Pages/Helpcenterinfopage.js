import Navbar from "../Components/Navbar";
import Helpcenterinfocomp from "../Components/Helpcenterinfocomp";
import Footer from "../Components/Footer";
import Helpcenterinfocomponent from "../Components/Helpcenterinfocomponent";

export default function Helpcenterinfopage(){
    
    return(
        <div>
        <Navbar />
        <Helpcenterinfocomponent />
        <Footer/>
        </div>
    )
}