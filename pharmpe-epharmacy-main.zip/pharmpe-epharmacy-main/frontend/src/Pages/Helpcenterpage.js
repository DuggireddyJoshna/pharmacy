import Helpcentercomp from "../Components/Helpcentercomp";
import Navbar from "../Components/Navbar";
import Footer from "../Components/Footer";
export default function Helpcenterpage(){
    return(
     <div>
        <Navbar/>
        <Helpcentercomp/>
        <Footer/>
     </div>
    )
}