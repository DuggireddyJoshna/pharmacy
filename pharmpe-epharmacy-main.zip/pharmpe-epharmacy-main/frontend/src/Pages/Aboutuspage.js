import React from "react";
import Navbar from "../Components/Navbar";
import Aboutus from "../Components/Aboutus";
import Footer from "../Components/Footer";

export default function Aboutuspage(){
return(
    <div>
    <Navbar />
    <Aboutus />
    <Footer />
   </div>
);
}