import Navbar from "../Components/Navbar";
import Footer from "../Components/Footer";
import PaymentForm from "../Components/PaymentForm";
export default function Paymentformpage(){
    return(
        <div>
            <Navbar/>
            <PaymentForm/>
            <Footer/>
        </div>
    )
}