import ShippingAddress from "../Components/ShippingAddress";

import Navbar from "../Components/Navbar";
import Footer from "../Components/Footer";
export default function Addresspage(){
    return(
        <div>
            <Navbar/>
         <ShippingAddress/>
          <Footer/>
        </div>
    )
}