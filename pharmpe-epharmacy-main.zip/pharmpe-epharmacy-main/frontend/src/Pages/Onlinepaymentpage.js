import Onlinepay from "../Components/onlinepay";
import Navbar from "../Components/Navbar";
import Footer from "../Components/Footer"
export default function Onlinepaymentpage(){
    return(
        <div>
            <Navbar/>
            <Onlinepay/>
            <Footer/>
        </div>
    )
}