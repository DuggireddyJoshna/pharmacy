import ProductList from "../Components/ProductList"
import Navbar from "../Components/Navbar"
import Footer from "../Components/Footer"
export default function ProductListpage(){
    return(
  <div>
    <Navbar/>
    <ProductList/>
    <Footer/>
  </div>
    )
}