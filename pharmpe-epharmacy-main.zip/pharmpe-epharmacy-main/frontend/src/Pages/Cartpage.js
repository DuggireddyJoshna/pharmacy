import React from "react";
import Navbar from "../Components/Navbar";
import Cartitemdetailscomp from "../Components/Cartitemdetailscomp"
import Footer from "../Components/Footer";

export default function Cartpage(){
return(
    <div>
    <Navbar />
    <Cartitemdetailscomp />
    <Footer />
   </div>
);
}