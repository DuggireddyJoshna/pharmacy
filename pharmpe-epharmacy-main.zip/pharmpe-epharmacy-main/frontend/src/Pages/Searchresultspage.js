import Productsearchres from "../Components/Productsearchres";
export default function Searchresultspage(){
    return(
        <Productsearchres/>
    )
}